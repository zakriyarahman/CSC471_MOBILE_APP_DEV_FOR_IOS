// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//
//  A Primer of Swift – Part 1
//

// Program 1.1
print("Hello, world!")

// Program 1.2
print("你好, 世界!")
print("👋🌎❗️")

