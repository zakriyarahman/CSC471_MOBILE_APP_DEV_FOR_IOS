// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// Program 2.1
let distanceToMoon = 384_400        // km
let earthGravityAcceleration = 9.8  // m/s/s
let languageName = "Swift"
let swiftIsAwesome = true

var total = 100
var velocity = 30.5
var statusMessage = "Success"
var isComplete = false