//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*: 
This playground contains the sample code for the _A Primer of Swift 2.1, Part 1: The Basics

This is a multi-page playground. Open the Project Navigator to see all the pages.

To switch views between the raw markups and the rendered markups: In the Xcode menu bar select Editor and then Show Rendered Markup. To switch back, select Show Raw Markup.

*/

//: # A Primer of Swift 2.1 – Part 1

//: ### Program 1.1: _Hello, World!_
print("Hello, world!")

//: ### Program 1.2: _Hello, World!_ in Chinese and Emoji
print("你好, 世界!")
print("👋🌎❗️")

//: [Next](@next)
