//: [Previous](@previous)

import Foundation

//: ### Program 2.1: Constant and Variable Declarations.
let distanceToMoon = 384_400        // km
let earthGravityAcceleration = 9.8  // m/s/s
let languageName = "Swift"
let swiftIsAwesome = true

var total = 100
var velocity = 30.5
var statusMessage = "Success"
var isComplete = false

//: [Next](@next)
