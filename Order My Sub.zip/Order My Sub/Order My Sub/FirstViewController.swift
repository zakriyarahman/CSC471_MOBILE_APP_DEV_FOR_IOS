//
//  FirstViewController.swift
//  Order My Sub
//
//  Created by Xiaoping Jia on 4/18/15.
//  Copyright (c) 2015 DePaul University. All rights reserved.
//

import UIKit

let subs = [
    "Blockbuster",
    "Roast Beef",
    "Italian Special",
    "Corned Beef",
    "Big \"Al\" Italian",
    "Tuna",
    "Wise Guy",
    "Chicken Salad ",
    "Caputo",
    "Veggie",
    "Prosciutto",
    "Turkey Breast",
    "American"
]

class FirstViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var picker: UIPickerView!
    
    
    @IBAction func seleted(sender: UIButton) {
        let title = "Order My Sub"
        let message = "You have selected \(subs[picker.selectedRowInComponent(0)])"
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        // Create the action.
        let cancelAction = UIAlertAction(title: "Cancel", style: .Destructive, handler: nil)
        let okayAction = UIAlertAction(title: "Confirm", style: .Default, handler: nil)
        alertController.addAction(cancelAction)
        alertController.addAction(okayAction)
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    // MARK: UIPickerViewDataSource
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return subs.count
    }
    
    // MARK: UIPickerViewDelegate
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return subs[row]
    }
    
}

