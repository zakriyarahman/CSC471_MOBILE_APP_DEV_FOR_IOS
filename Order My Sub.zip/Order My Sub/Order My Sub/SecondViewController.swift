//
//  SecondViewController.swift
//  Order My Sub
//
//  Created by Xiaoping Jia on 4/18/15.
//  Copyright (c) 2015 DePaul University. All rights reserved.
//

import UIKit

let sizes = [
    "6 inch",
    "8 inch",
    "10 inch",
    "12 inch",
    "16 inch",
    "3 foot"
]

class SecondViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var picker: UIPickerView!
    
    @IBAction func selected(sender: UIButton) {
        let title = "Order My Sub"
        let message = "You have selected \(sizes[picker.selectedRowInComponent(1)]) \(subs[picker.selectedRowInComponent(0)])"
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .ActionSheet)
        
        // Create the action.
        let cancelAction = UIAlertAction(title: "Cancel", style: .Destructive) { action in
            let cancelController = UIAlertController(title: "No Problem", message: "Select again.", preferredStyle: .Alert)
            let okayAction = UIAlertAction(title: "Okay", style: .Default, handler: nil)
            cancelController.addAction(okayAction)
            self.presentViewController(cancelController, animated: true, completion: nil)
        }
        let confirmAction = UIAlertAction(title: "Confirm", style: .Default) { action in
            let dateFormat = NSDateFormatter()
            dateFormat.dateFormat = "MM/dd/yyyy hh:mma"
            let dateString = dateFormat.stringFromDate(date)
            let okayController = UIAlertController(title: "Thank You!", message: "Your order will be ready by \(dateString).", preferredStyle: .Alert)
            let okayAction = UIAlertAction(title: "Okay", style: .Default, handler: nil)
            okayController.addAction(okayAction)
            self.presentViewController(okayController, animated: true, completion: nil)
        }
        alertController.addAction(cancelAction)
        alertController.addAction(confirmAction)
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: UIPickerViewDataSource
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return subs.count
        } else {
            return sizes.count
        }
    }
    
    // MARK: UIPickerViewDelegate
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return subs[row]
        } else {
            return sizes[row]
        }
    }
    
}

